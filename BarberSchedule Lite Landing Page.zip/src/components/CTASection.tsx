import { Button } from "./ui/button";
import { useNavigate } from "react-router";

export function CTASection() {
  const navigate = useNavigate();

  return (
    <section className="bg-[#1A1A1A] pt-20 pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Headline */}
        <h2 className="text-white mb-4">
          Preparado?
        </h2>

        {/* Supporting Text */}
        <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
          Junte-se a centenas de clientes, que confiam em nós para suas necessidades.
        </p>

        {/* CTA Button */}
        <Button 
          onClick={() => navigate("/booking")}
          className="bg-[#E67E22] hover:bg-[#D35400] text-white"
        >
          Comece Agora!
        </Button>
      </div>
    </section>
  );
}